//Stuff all/most of BasicFX shared shaders need
NAMESPACE_ENTER(BFX)
#define BFX_SETTINGS_DEF "ReShade/BasicFX.cfg"
#define BFX_SETTINGS_UNDEF "ReShade/BasicFX.undef" 

#include BFX_SETTINGS_DEF

//put your basic stuff here

#include BFX_SETTINGS_UNDEF
NAMESPACE_LEAVE()